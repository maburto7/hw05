// Implementation file for patient.cpp
#include "person.h"
#include "date.h"
#include "patient.h"
#include <string>
#include <iostream>



Patient::Patient(const std::string& id, const std::string& fName, const std::string& lName,
                const Date& birthday, const Doctor* doctor, const Date& admission, 
                std::string specialty)
    : Person(fName, lName), ID(id), dateOfBirth(birthday), 
      attendingPhysician(doctor),neededSpecialty(specialty), admitDate(admission) {}


    
// keep this destructor implementation empty.
Patient::~Patient() noexcept {
}



void Patient::print(std::ostream& out) const {
    out << std::endl<<"Patient: ";
    Person::print(out);

    out << std::endl << "Attending Physician: ";
    if(getAttending()!=nullptr) attendingPhysician->print(out);
    
    out << std::endl << "Admit Date: ";
    admitDate.printDate(out);
    out<<std::endl;

    out << "Discharge Date: ";
    dischargeDate.printDate(out);
    out<<std::endl;
}

std::string Patient::getID() const{
    return ID;
}

Date Patient::getBirthDate() const{
    return dateOfBirth;
}

void Patient::setBirthDate(const Date& date){
    dateOfBirth = date;
}

const Doctor * Patient::getAttending() const{
    return attendingPhysician;
}
void Patient::setAttending(const Doctor * doctor){
    attendingPhysician = doctor;
}

Date Patient::getAdmissionDate() const{
    return admitDate;
}

Date Patient::getDischargeDate() const{
    return dischargeDate;  
}

void Patient::setDisDate(const Date& date){
    dischargeDate = date;
}

std::string Patient::getNeededSpecialty() const{
    return neededSpecialty;
}

void Patient::setNeededSpecialty(const std::string& specialty) {
    neededSpecialty = specialty;
}



//Patient::~Patient() noexcept override{}

 