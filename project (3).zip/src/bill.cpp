// Implementation file bill.cpp
#include "bill.h"
#include <string>
#include <iostream>

Bill::Bill(const std::string & id, double phCharges, double rRent, double docFee)
    :ID(id),pharmacyCharges(phCharges),roomRent(rRent),doctorFee(docFee){}


void Bill::printBill(std::ostream& out) const{
    out<<std::endl<<std::fixed <<std::setprecision(2);

    out<<std::left<<std::setw(18)<<"Pharmacy Charges: "<<'$'<<std::right<<std::setw(6)<<pharmacyCharges<<std::endl;

    out<<std::left<<std::setw(18)<<"Room Charges: "<<'$'<<std::right<<std::setw(6)<<roomRent<<std::endl;

    out<<std::left<<std::setw(18)<<"Doctor's Fees: "<<'$'<<std::right<<std::setw(6)<<doctorFee<<std::endl;

    out<<"______________________________"<<std::endl;
    
    out<<std::left<<std::setw(18)<<"Total Charges: "<<'$'<<std::right<<std::setw(6)<<Bill::billingAmount()<<std::endl;
}


std::string Bill::getID() const{
    return ID;
}

void Bill::setPharmacyCharges(double charges){
    pharmacyCharges = charges;
}
double Bill::getPharmacyCharges() const{
    return pharmacyCharges;
}
void Bill::addPharmacyCharges(double charges){
    pharmacyCharges+=charges;
}

void Bill::setRoomRent(double charges){
    roomRent = charges;
}
double Bill::getRoomRent() const{
    return roomRent;
}
void Bill::addRoomRent(double charges){
    roomRent+=charges;
}

void Bill::setDoctorFee(double charges){
    doctorFee = charges;
}

double Bill::getDoctorFee() const{
    return doctorFee;
    }

void Bill::addDoctorFee(double charges){
    doctorFee += charges;
}

// billing amount is the sum of the three fees (Pharmacy charges, room rent, and the doctor fee).
double Bill::billingAmount() const{
    return pharmacyCharges + roomRent + doctorFee;
}

