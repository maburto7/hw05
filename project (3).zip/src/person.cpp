// Implementation file person.cpp

#include "person.h"
#include <string>
#include <iostream>


void Person::print(std::ostream& os) const {
    os << getFirstName() << " " << getLastName();
}

std::string Person::getFirstName() const {
    return firstName;
}

std::string Person::getLastName() const {
    return lastName;
}

//Person(const std::string & first, const std::string & last);
//initialize first and last name
Person::Person(const std::string& first, const std::string& last)
    : firstName(first), lastName(last) {}
